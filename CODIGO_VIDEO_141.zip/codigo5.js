function generarTabla(operacion) {
    const numero = parseInt(document.getElementById('numero').value);
    if (isNaN(numero)) { 
        alert('Por favor, introduce un número válido.');
        return;
    }

    let tabla = `<table><thead><tr><th>Operación</th><th>Resultado</th></tr></thead><tbody>`;

    for (let i = 1; i <= 10; i++) {
        let resultado;
        switch (operacion) {
            case 'sumar':
                resultado = numero + i;
                tabla += `<tr><td>${numero} + ${i}</td><td>${resultado}</td></tr>`;
                break;
            case 'restar':
                resultado = numero - i;
                tabla += `<tr><td>${numero} - ${i}</td><td>${resultado}</td></tr>`;
                break;
            case 'multiplicar':
                resultado = numero * i;
                tabla += `<tr><td>${numero} * ${i}</td><td>${resultado}</td></tr>`;
                break;
            case 'dividir':
                if (i !== 0) {
                    resultado = (numero / i).toFixed(2);
                    tabla += `<tr><td>${numero} / ${i}</td><td>${resultado}</td></tr>`;
                }
                break;
        } // fin del switch
    } // fin del for

    tabla += `</tbody></table>`;
    document.getElementById('tabla-resultado').innerHTML = tabla;
}
