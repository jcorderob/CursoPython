from flask import Flask, render_template, flash, redirect, url_for, request
from config import Config
import pymysql
from models.alumno_model import get_alumno_by_dni, get_alumno_by_id, get_all_alumnos, delete_alumno, add_alumno

app = Flask(__name__)

# Cargar la configuración
app.config.from_object(Config)

# ------------ Inicio -----------------
@app.route('/')
def index():
    return render_template('index.html')

# -----------------------------------
@app.route('/registrar', methods=['GET', 'POST'])
def registra():
    if request.method == 'POST':
        dni = request.form['dni']
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        fecha = request.form['fecha']
        email = request.form['email']
        telefono = request.form['telefono']
        try:
            add_alumno(dni, nombre, apellido, fecha, email, telefono)
            flash("El alumno ha sido registrado correctamente.", "success")
        except:
            flash("No se pudo registrar el alumno", "danger")
    return render_template('registrar_alumnos.html')

# -----------------------------------
@app.route('/consultar', methods=['GET', 'POST'])
def consulta():
    if request.method == 'POST':
        dni = request.form['dni']  # debe coincidir con el atributo 'name' del form.   
        try:
            alumno_buscado = get_alumno_by_dni(dni)
            if alumno_buscado:
                return render_template('consultar_alumnos.html', alumno=alumno_buscado)
            else: 
                flash("DNI no registrado!!!", "danger")

        except pymysql.MySQLError as e:
            print(f"Error: {e}")
            flash("No se encontró ningún alumno con el DNI proporcionado.", "danger")
    
    return render_template('consultar_alumnos.html')        
    

# -----------------------------------
@app.route('/listar')
def lista():
    listaAlumnos = get_all_alumnos()
    return render_template('listar_alumnos.html', totalAlumnos=listaAlumnos)

# -----------------------------------
@app.route('/modificar', methods=['GET', 'POST'])
@app.route('/modificar/<int:alumno_id>', methods=['GET'])
def modifica(alumno_id=None):
    if request.method == 'POST':
        dni = request.form['dni']
        alumno_buscado = get_alumno_by_dni(dni)
        if alumno_buscado:
            return render_template('modificar_alumnos.html', alumno=alumno_buscado)
        else:
            flash("No se encontró ningún alumno con el DNI proporcionado.", "danger")
            return redirect(url_for('modifica'))
   
    if alumno_id:
        alumno_buscado = get_alumno_by_id(alumno_id)
        if alumno_buscado:
            return render_template('modificar_alumnos.html', alumno=alumno_buscado)
        else:
            flash("No se encontró ningún alumno con el ID proporcionado.", "danger")
            return redirect(url_for('modifica'))

    return render_template('modificar_alumnos.html')

# -----------------------------------
@app.route('/eliminar/<int:id>')
def elimina(id):
    try:
        delete_alumno(id)
        flash("Alumno eliminado", "success")
    except pymysql.MySQLError as e:
        print(f"Error: {e}")
        flash("No se pudo eliminar el alumno, tiene cursos registrados", "danger")
    return redirect(url_for('lista'))

# ------------ INICIO -------------
if __name__ == '__main__':
    app.run(debug=True)
