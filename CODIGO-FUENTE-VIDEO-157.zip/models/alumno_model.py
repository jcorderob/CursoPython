import pymysql
from flask import current_app, g   # 'g' es un objeto
#from flask.cli import with_appcontext
import click

def get_db():   # conectarse a la base de datos
    if 'db' not in g:
        g.db = pymysql.connect(
            host=current_app.config['MYSQL_HOST'],
            port=current_app.config['MYSQL_PORT'],
            user=current_app.config['MYSQL_USER'],
            password=current_app.config['MYSQL_PASSWORD'],
            db=current_app.config['MYSQL_DB']
        )
    return g.db

def close_db(e=None):      # cerrar la conexión a la base de datos
    db = g.pop('db', None) # conexion abierta se devuelve, sino 'None'
    if db is not None:     # hay una conexion abierta
        db.close()



def get_all_alumnos():
    db = get_db()
    with db.cursor(pymysql.cursors.DictCursor) as cursor: 
                            # Se especifica que cada  registro sea 1 diccionario.
        cursor.execute("SELECT * FROM alumnos") 
                      # ejecuta comando y prepara cursor pero no devuelve datos
        return cursor.fetchall()
                      # es quien devuelve todos los diccionarios dentro de 1 lista


def get_alumno_by_dni(dni):
    db = get_db()
    with db.cursor(pymysql.cursors.DictCursor) as cursor:
        cursor.execute("SELECT * FROM alumnos WHERE alumnodni = %s", (dni))
        return cursor.fetchone() # pasa los datos a la RAM

def get_alumno_by_id(alumno_id):
    db = get_db()
    with db.cursor(pymysql.cursors.DictCursor) as cursor:
        cursor.execute("SELECT * FROM alumnos WHERE alumnoid = %s", (alumno_id,))
        return cursor.fetchone()

def add_alumno(dni, nombre, apellido, fecha_nacimiento, email, telefono):
    db = get_db()
    with db.cursor() as cursor:
        cursor.execute(
            "INSERT INTO alumnos (alumnodni, nombre, apellido, fechanacimiento, email, telefono) VALUES (%s, %s, %s, %s, %s, %s)",
            (dni, nombre, apellido, fecha_nacimiento, email, telefono)
        )
        db.commit() # concreta la inserción

def update_alumno(alumno_id, dni, nombre, apellido, fecha_nacimiento, email, telefono):
    db = get_db()
    with db.cursor() as cursor:
        cursor.execute(
            "UPDATE alumnos SET alumnodni = %s, nombre = %s, apellido = %s, fechanacimiento = %s, email = %s, telefono = %s WHERE alumnoid = %s",
            (dni, nombre, apellido, fecha_nacimiento, email, telefono, alumno_id)
        )
        db.commit()

def delete_alumno(alumno_id):
    db = get_db()
    with db.cursor() as cursor:
        cursor.execute("DELETE FROM alumnos WHERE alumnoid = %s", (alumno_id))
        print("borrado")
        db.commit() # concreta el borrado
