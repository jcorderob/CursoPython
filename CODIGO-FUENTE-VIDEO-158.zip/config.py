import os

class Config:
    """Base configuration."""
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your_secret_key'
    MYSQL_HOST = 'localhost' # QUE LA BASE DE DATOS ESTA EN EL MISMO LUGAR
                             # DONDE ESTA CORRIENDO LA APLICACIÓN
    MYSQL_PORT = 3306
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = ''
    MYSQL_DB = 'academia'
