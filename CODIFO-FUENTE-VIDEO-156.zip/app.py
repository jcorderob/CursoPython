from flask import Flask, render_template, flash, redirect, url_for, request
from config import Config
import os, pymysql
from models.alumno_model import get_all_alumnos, delete_alumno, add_alumno

app = Flask(__name__)  # creamos el <<Objeto>> aplicación

# Cargar la configuración
app.config.from_object(Config)

# ------------ Inicio -----------------
@app.route('/')  # esta es la ruta root o raiz
def index():
    return render_template('index.html')  # redirigir a la plantilla 'index.html'


# -----------------------------------
@app.route('/registrar', methods=['GET', 'POST'])  # esta es la ruta hacia registro de alumnos
def registra():
    if request.method == 'POST':
        
        dni = request.form['dni']
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        fecha = request.form['fecha']
        email = request.form['email']
        telefono = request.form['telefono']
        try:
            add_alumno(dni, nombre, apellido, fecha, email, telefono)
            flash("El alumno ha sido registrado correctamente.", "success")
        except:
            flash("No se pudo Registrar el alumno", "danger")
    
    return render_template('registrar_alumnos.html')  # redirigir a la plantilla 'registrar_alumnos.html'


# -----------------------------------
@app.route('/consultar')  # esta es la ruta hacia consulta de alumnos
def consulta():
    return render_template('consultar_alumnos.html')  # redirigir a la plantilla 'consultar_alumnos.html'


# -----------------------------------
@app.route('/listar')  # esta es la ruta hacia listado de alumnos
def lista():
    
    listaAlumnos = get_all_alumnos()

    return render_template('listar_alumnos.html', totalAlumnos=listaAlumnos)  # redirigir a la plantilla 'listar_alumnos.html'

# -----------------------------------
@app.route('/modificar')  # esta es la ruta  hacia modificación  de alumnos
def modifica():
    return render_template('modificar_alumnos.html')  # redirigir a la plantilla 'modificar_alumnos.html'


# -----------------------------------
@app.route('/eliminar/<int:id>')
def eliminarAlumnos(id):
    
    try:
        delete_alumno(id)
        flash("Alumno eliminado", "success")
    except pymysql.MySQLError:
        flash("No se pudo eliminar el alumno, tiene Cursos registrados", "danger")
    return redirect(url_for('lista'))


# ------------ INICIO -------------
if __name__ == '__main__':
    app.run(debug=True)
