import os
from clases.mis_clases import Trabajador, GestorTrabajadores
from utilidades.validaciones import *

def main():
    gestor = GestorTrabajadores() # es un OBJETO con una propiedad tipo LISTA
                                  
    while True:
        os.system("cls")
        print("\n1. Registrar trabajador")
        print("2. Buscar trabajador")
        print("3. Eliminar trabajador")
        print("4. Listar trabajadores")
        print("5. Salir")

        opcion = input("Seleccione una opción: ")

        if opcion == '1':
            dni = input("DNI: ")
            nombre_apellido = input("Nombre y Apellido: ")
            anio_de_ingreso = input("Año de Ingreso: ")
            sexo = input("Sexo (M/F): ").upper()
            edad = input("Edad: ")
            salario = input("Salario: ")

            if (validar_dni(dni) and validar_nombre_apellido(nombre_apellido) and
                validar_anio_de_ingreso(anio_de_ingreso) and validar_sexo(sexo) and
                validar_edad(edad) and validar_salario(salario)):
                
                gestor.registrar_trabajador(dni, nombre_apellido, anio_de_ingreso, sexo, edad, salario)
                print("\nTrabajador registrado exitosamente.")
            else:
                print("Datos inválidos. Por favor, intente nuevamente.")

            input("\nPress any key to continue ...")

        elif opcion == '2':
            dni = input("DNI: ")
            trabajador = gestor.buscar_trabajador(dni)
            if trabajador:   # True si tiene contenido, sino devuelve False
                print(trabajador)
            else:
                print("\nTrabajador no encontrado.")

            input("\nPress any key to continue ...")

        elif opcion == '3':
            dni = input("DNI: ")
            if gestor.eliminar_trabajador(dni):
                # Aquí falta mostrar los datos
                print("\nTrabajador eliminado exitosamente.")
            else:
                print("\nTrabajador no encontrado.")
            
            input("\nPress any key to continue ...")

        elif opcion == '4':
            trabajadores = gestor.listar_trabajadores()
            for trabajador in trabajadores:
                print(trabajador)
            
            input("\nPress any key to continue ...")

        elif opcion == '5':
            break

        else:
            print("Opción no válida. Por favor, intente nuevamente.")

if __name__ == '__main__':
    main()
