# Clase trabajador.
class Trabajador:
    def __init__(self, dni, nombre_apellido, anio_de_ingreso, sexo, edad, salario):
        self.dni = dni
        self.nombre_apellido = nombre_apellido
        self.anio_de_ingreso = anio_de_ingreso
        self.sexo = sexo
        self.edad = edad
        self.salario = salario

    def __str__(self):
        return (f"DNI= {self.dni}, Nombre y Apellido= {self.nombre_apellido}, Año de Ingreso= {self.anio_de_ingreso}, "
                f"Sexo= {self.sexo}, Edad: {self.edad}, Salario: {self.salario}")


# Clase para la gestión de trabajadores.
class GestorTrabajadores:
    def __init__(self):
        self.trabajadores = []    # Crea un atributo que es una LISTA vacía

    def registrar_trabajador(self, dni, nombre_apellido, anio_de_ingreso, sexo, edad, salario):
        trabajador = Trabajador(dni, nombre_apellido, anio_de_ingreso, sexo, edad, salario)
        self.trabajadores.append(trabajador)

    def buscar_trabajador(self, dni):
        for trabajador in self.trabajadores:
            if trabajador.dni == dni:
                return trabajador
        return None

    def eliminar_trabajador(self, dni):
        trabajador = self.buscar_trabajador(dni)
        if trabajador:
            self.trabajadores.remove(trabajador)
            return True
        return False

    def listar_trabajadores(self):
        return self.trabajadores
