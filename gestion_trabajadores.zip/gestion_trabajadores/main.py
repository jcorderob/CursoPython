import os
from modulos.registrar import registrar_trabajadores
from modulos.consultar import consultar_trabajadores
from modulos.eliminar import eliminar_trabajadores
from modulos.listar import listar_trabajadores


# --------------------------  Función main() 
# -------------------------- Mostrar Menú y controlar la lógica del sistema
def main():
    # Lista vacía para almacenar los datos de los trabajadores
    lista_trabajadores = []
    while True:
        os.system("cls")
        print("\n\n\033[32m     *MENÚ DE OPCIONES*\033[0m")
        print("                     Opción".rjust(33))
        print("                     ------".rjust(33))
        print("Registrar trabajador ....... 1")
        print("Consultar trabajador ....... 2")
        print("Eliminar trabajador  ....... 3")
        print("Listar trabajadores  ....... 4")
        print("\033[33mSalir  ....... 0 \033[0m".rjust(40))
        while True:
            opcion = input("\033[32mOpción? \033[0m ".rjust(32))
            if opcion  in ['0','1','2','3','4']:
                break
            else:
                print("Opción inválida")

        if   opcion == '1': registrar_trabajadores(lista_trabajadores) 
        elif opcion == '2': consultar_trabajadores(lista_trabajadores)
        elif opcion == '3': eliminar_trabajadores(lista_trabajadores)
        elif opcion == '4': listar_trabajadores(lista_trabajadores)
        elif opcion == '0': break


# Cuerpo principal del programa
if __name__ == "__main__":
    main()
