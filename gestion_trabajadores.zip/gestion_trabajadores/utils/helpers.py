
# --------------------------  Función Buscar dni 
def buscar_dni(dni_buscado, lista_trabajadores):
    for indice, trabajador in enumerate(lista_trabajadores):
        if trabajador['dni'] == dni_buscado:
            return True, indice, trabajador # Devuelve una tupla
    return False, None




