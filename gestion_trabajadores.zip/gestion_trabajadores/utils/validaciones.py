# --------------------------  Función Validar año de ingreso
# --------------------------  Manejo de excepciones 
def validar_anio():
    while True:           
            entrada = input("Año de ingreso    :")  
            try:
                # Intentar convertir la entrada a un número entero
                anio = int(entrada)
                return anio
            except ValueError:
                print("\033[33mPor favor, ingrese una edad válida.\033[0m") 


# --------------------------  Función Validar entero
def validar_edad():
    while True:           
            entrada = input("Edad              :")  
            try:
                # Intentar convertir la entrada a un número entero
                edad = int(entrada)
                return edad
            except ValueError:
                print("\033[33mPor favor, ingrese una edad válida.\033[0m") 


# --------------------------- Funcion Validar sexo
def validar_sexo():
    while True:          
            entrada= input("Sexo (F/M)        : ").upper()
            if entrada in ['F','M']:
                return entrada
            else:
                print("\033[33mEl sexo debe ser F o M\033[0m")


def validar_salario():
        while True:         
            entrada= input("salario           : ")
            try:
                # intentar convertir entrada a numero flotante
                salario = float(entrada)
                return salario
            except:
                print("\033[33mPor favor, ingrese un salario válido.\033[0m")  


