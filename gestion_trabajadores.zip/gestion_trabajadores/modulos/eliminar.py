import os
from utils.helpers import buscar_dni
# --------------------------  Función Registrar   
def eliminar_trabajadores(lista_trabajadores):
    while True: 
        os.system("cls")
        print("\n\n     \033[32m** MÓDULO ELIMINAR **\033[0m")
        dni_a_buscar = input("\nDNI de trabajador o \033[33m'000'\033[m para retornar al Menú :")
        if dni_a_buscar == '000': 
            break
        else:
            resultado_busqueda = buscar_dni(dni_a_buscar, lista_trabajadores)
            if resultado_busqueda[0] == True:
                trabajador = resultado_busqueda[2]
                respuesta = input(f"Desea eliminar a {trabajador['nombre_apellido']} S/N ?")
                if respuesta.upper() == 'S':
                    indice = resultado_busqueda[1]
                    del lista_trabajadores[indice]
                    input("\nTrabajador eliminado, presione <enter>")
            else:
                input(f"\nDNI \033[32m{dni_a_buscar}\033[0m no registrado, presione <enter>")    

