import os
from utils.validaciones import validar_anio, validar_edad, validar_sexo, validar_salario
from utils.helpers import buscar_dni

# --------------------------  Función Registrar   
def registrar_trabajadores(lista_trabajadores):
    trabajador = {}
    # Ciclo para ingresar los datos de múltiples trabajadores
    while True:
        os.system("cls")
        print("\n\n\033[32m** MÓDULO REGISTRO DE TRABAJADORES **\033[0m\n")
        # Solicitar al usuario que ingrese los datos del trabajador
        dni_a_buscar = input("Ingrese el dni o '\033[33m000\033[0m' para volver al Menú: ")
        # Si el usuario ingresa "000", se rompe el ciclo
        if dni_a_buscar == '000':
            break
        else:
            resultado_busqueda = buscar_dni(dni_a_buscar, lista_trabajadores) 
            # Se recible una tupla
            if resultado_busqueda[0] == True:
                print(f"\nDNI \033[32m{dni_a_buscar}\033[0m ya registrado!!")
                trabajador = resultado_busqueda[2] 
                input(f"\nPertenece al trabajador: {trabajador['nombre_apellido']}") 
                continue    
            else:
                trabajador['dni'] = dni_a_buscar
                trabajador['nombre_apellido'] = input("Nombre y apellido : ").lower().title()    
                trabajador['año_de_ingreso'] = validar_anio()
                trabajador['sexo'] = validar_sexo()
                trabajador['edad'] = validar_edad()
                trabajador['salario'] = validar_salario()
                # Agregar una copia del diccionario <trabajador> a la lista de trabajadores
                lista_trabajadores.append(trabajador.copy())
                input("\nTrabajador Registrado, presione <enter>")

                
