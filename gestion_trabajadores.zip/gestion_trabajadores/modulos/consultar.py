import os
from utils.helpers import buscar_dni
# --------------------------  Función Consultar   
def consultar_trabajadores(lista_trabajadores):
    while True:
        os.system("cls")
        print("\n\n     \033[32m** MÓDULO CONSULTAR **\033[0m")
        dni_a_buscar = input("\nIngrese DNI de trabajador o \033[33m'000'\033[m " 
                             "para retornar al Menú :")
        if  dni_a_buscar == '000': break
        else:
            resultado_busqueda = buscar_dni(dni_a_buscar, lista_trabajadores) 
            # Devuelve una tupla
            if resultado_busqueda[0] == True:             # if resultado_busqueda[0] : 
                trabajador = resultado_busqueda[2]
                print("DNI        : ", trabajador['dni'])
                print("NOMBRE     : ", trabajador['nombre_apellido'])
                print("AÑO INGRESO: ", trabajador['año_de_ingreso'])
                print("SEXO       : ", trabajador['sexo']) 
                print("EDAD       : ", trabajador['edad'])
                print("SALARIO    : ", trabajador['salario'])
            else:
                print(f"\nDNI = \033[32m{dni_a_buscar}\033[0m, no está registrado!!.")

            input("\n\nPresione una tecla para continuar ...")         

