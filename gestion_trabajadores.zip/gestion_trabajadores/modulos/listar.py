import os
# --------------------------  Función Listar 
def listar_trabajadores(lista_trabajadores):
    # Imprimir la lista de trabajadores
    os.system("cls")
    print("\n\033[32m            ** REPORTE DE TRABAJADORES **\n")
    print("Nro   DNI   NOMBRE           AÑO INGRESO SEXO     EDAD    salario")
    print("===   ===   ======           =========== ====     ====    ======\033[0m")
    acumula_salario = 0
    for contador, trabajador in enumerate(lista_trabajadores, 1):
        print(f"{contador:<6}{trabajador['dni']:<6}{trabajador['nombre_apellido']:<20}"  
              f"{trabajador['año_de_ingreso']:<10}{trabajador['sexo']:<9}"    
              f"{trabajador['edad']:<7}"  f"{trabajador['salario']:.2f}")
        
        acumula_salario += trabajador['salario']

    salario_promedio = acumula_salario / len(lista_trabajadores)
    print("---------".rjust(66))  
    print("Salario Promedio:".rjust(41),end="")
    print(f"\033[32m{salario_promedio:>25.2f}\033[0m")
        
    input("\n\nPresione una tecla para continuar ...")


