from flask import  Blueprint, render_template, flash, redirect, url_for, request
from config import Config
import pymysql
from models.alumno_model import get_alumno_by_dni, get_alumno_by_id, get_all_alumnos, delete_alumno, add_alumno, update_alumno

# Definición del blueprint.

alumnos_bp = Blueprint('alumnos', __name__)


# -----------------------------------
@alumnos_bp.route('/registrar', methods=['GET', 'POST'])
def registra():
    if request.method == 'POST':
        dni = request.form['dni']
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        fecha = request.form['fecha']
        email = request.form['email']
        telefono = request.form['telefono']
        try:
            add_alumno(dni, nombre, apellido, fecha, email, telefono)
            flash("El alumno ha sido registrado correctamente.", "success")
        except:
            flash("No se pudo registrar el alumno", "danger")
    return render_template('registrar_alumnos.html')

# -----------------------------------
@alumnos_bp.route('/consultar', methods=['GET', 'POST'])
def consulta():
    if request.method == 'POST':
        dni = request.form['dni']  # debe coincidir con el atributo 'name' del form.   
        try:
            alumno_buscado = get_alumno_by_dni(dni)
            if alumno_buscado:
                return render_template('consultar_alumnos.html', alumno=alumno_buscado)
            else: 
                flash("DNI no registrado!!!", "danger")

        except pymysql.MySQLError as e:
            print(f"Error: {e}")
            flash("No se encontró ningún alumno con el DNI proporcionado.", "danger")
    
    return render_template('consultar_alumnos.html')        
    

# -----------------------------------
@alumnos_bp.route('/listar')
def lista():
    listaAlumnos = get_all_alumnos()
    return render_template('listar_alumnos.html', totalAlumnos=listaAlumnos)

# -----------------------------------
@alumnos_bp.route('/modificar', methods=['GET', 'POST'])
@alumnos_bp.route('/modificar/<int:alumnoid>', methods=['GET', 'POST'])
def modifica(alumnoid=None):

    if request.method == 'POST':
        if 'buscar' in request.form:
            
            dni = request.form['dni']
            alumno_buscado = get_alumno_by_dni(dni)
            if alumno_buscado:
                return render_template('modificar_alumnos.html', alumno=alumno_buscado)
            else: 
                flash("DNI no registrado!!!", "danger")

        elif 'modificar' in request.form:
            alumnoid = request.form['alumnoid']
            dni = request.form['dni']
            nombre= request.form['nombres'],
            apellido= request.form['apellidos'],
            fecha= request.form['fecha'],
            email= request.form['email'],
            telefono= request.form['telefono']

            try:
                update_alumno(alumnoid, dni, nombre, apellido, fecha, email, telefono)
                flash("Los datos del alumno han sido actualizados.", "success")
            except pymysql.MySQLError as e:
                print(f"Error: {e}")
                flash("No se pudieron actualizar los datos del alumno.", "danger")
            return render_template('modificar_alumnos.html')
        
        elif 'eliminar' in request.form:
            alumnoid = request.form['alumnoid']
            return redirect(url_for('elimina', alumnoid=alumnoid))

    if request.method == 'GET': 
            if alumnoid:
                alumno_buscado = get_alumno_by_id(alumnoid)
                if alumno_buscado:
                    return render_template('modificar_alumnos.html', alumno=alumno_buscado)
                else: 
                    flash("DNI no registrado!!!", "danger")

    return render_template('modificar_alumnos.html')
    

# -----------------------------------
@alumnos_bp.route('/eliminar/', methods=['GET', 'POST'])
@alumnos_bp.route('/eliminar/<int:alumnoid>', methods=['GET', 'POST'])
def elimina(alumnoid=None):

    try:
        delete_alumno(alumnoid)
        flash("Alumno eliminado", "success")
    except pymysql.MySQLError as e:
        print(f"Error: {e}")
        flash("No se pudo eliminar el alumno, tiene cursos registrados", "danger")
    
    return redirect(url_for('lista'))
