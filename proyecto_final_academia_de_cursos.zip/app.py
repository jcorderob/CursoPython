from flask import Flask, render_template
from config import Config

from blueprints.alumnos_blueprint import alumnos_bp



app = Flask(__name__)

# Cargar la configuración
app.config.from_object(Config)


# Registrar Blueprints
app.register_blueprint(alumnos_bp, url_prefix='/alumnos') 


@app.route('/')
def index():
    return render_template('index.html')

# ------------ INICIO -------------
if __name__ == '__main__':
    app.run(debug=True)
