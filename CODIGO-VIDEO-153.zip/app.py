from flask import Flask, render_template
from config import Config
import os 
from models.alumno_model import get_all_alumnos

app = Flask(__name__)  # creamos el <<Objeto>> aplicación

# Cargar la configuración
app.config.from_object(Config)

# ------------ Inicio -----------------
@app.route('/')  # esta es la ruta root o raiz
def index():
    return render_template('index.html')  # redirigir a la plantilla 'index.html'


# -----------------------------------
@app.route('/registrar')  # esta es la ruta hacia registro de alumnos
def registra():
    return render_template('registrar_alumnos.html')  # redirigir a la plantilla 'index.html'


# -----------------------------------
@app.route('/consultar')  # esta es la ruta hacia consulta de alumnos
def consulta():
    return render_template('consultar_alumnos.html')  # redirigir a la plantilla 'index.html'


# -----------------------------------
@app.route('/listar')  # esta es la ruta hacia listado de alumnos
def lista():
    filas = 5
    return render_template('listar_alumnos.html', numFilas=filas)  # redirigir a la plantilla 'index.html'


# -----------------------------------
@app.route('/modificar')  # esta es la ruta  hacia modificación  de alumnos
def modifica():
    return render_template('modificar_alumnos.html')  # redirigir a la plantilla 'index.html'


# -----------------------------------
@app.route('/eliminar')  # esta es la ruta  hacia eliminación  de alumnos
def elimina():
    return render_template('eliminar_alumnos.html')  # redirigir a la plantilla 'index.html'

# ------------ INICIO -------------
if __name__ == '__main__':
    app.run(debug=True)
