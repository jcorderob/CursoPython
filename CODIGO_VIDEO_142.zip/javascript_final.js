function validarFormulario() {
    const nombre = document.getElementById('nombre').value;
    const email = document.getElementById('email').value;
    const genero = document.querySelector('input[name="genero"]:checked'); // botones radio
    const intereses = document.querySelectorAll('input[name="intereses"]:checked'); // con check boxes
    const pais = document.getElementById('pais').value;
    const mensaje = document.getElementById('mensaje').value;
    
    if (!nombre || !email || !genero || intereses.length === 0 || !pais || !mensaje) {
        alert('Por favor, completa todos los campos.');
        return false;  // impide el envio del formulario
    }

    if (!validarEmail(email)) {
        alert('Por favor, introduce un correo electrónico válido.');
        return false;   // impide el envio del formulario
    }

    mostrarResultado(nombre, email, genero.value, intereses, pais, mensaje);
    return false;  // Evita el envío del formulario para ver el resultado
}

function validarEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // expresiones regulares
    return regex.test(email);
}

function mostrarResultado(nombre, email, genero, intereses, pais, mensaje) {
    const resultadoDiv = document.getElementById('resultado');
    const interesesTexto = Array.from(intereses).map(interes => interes.value).join(', ');

    resultadoDiv.innerHTML = `
        <p><strong>Nombre:</strong> ${nombre}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Género:</strong> ${genero}</p>
        <p><strong>Intereses:</strong> ${interesesTexto}</p>
        <p><strong>País:</strong> ${pais}</p>
        <p><strong>Mensaje:</strong> ${mensaje}</p>
    `;
}
