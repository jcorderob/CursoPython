import os
from paquete_clases.clases import Persona, Profesional, \
     Estudiante, Deportista, Futbolista
from paquete_implementacion.implementacion import *

if __name__ == "__main__":
    implementacion()
 
